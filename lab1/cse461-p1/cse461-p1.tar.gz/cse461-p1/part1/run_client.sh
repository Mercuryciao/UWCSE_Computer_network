dname=$(dirname ${BASH_SOURCE[0]})
python3 $dname/client.py $1 $2