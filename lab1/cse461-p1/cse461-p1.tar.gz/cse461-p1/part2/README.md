# CSE461_computer_network
Name: Lauren Liao
Netid: 2276575

# Python Version
Python 3.9.6

# Secrets
A = 70, B = 41, C = 231, D = 398

# Instructions

sh run_server.sh "127.0.0.1" 41201
